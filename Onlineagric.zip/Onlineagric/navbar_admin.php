<div class="container">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="nav navbar-nav">
                    <li><a href="sales.php">Sales</a></li>
          <li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Maintenace <span class="caret"></span></a></li>
          <ul class="dropdown-menu">
            <li><a href="product.php">Products</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="category.php">Category</a></li>
                    <!---
                    <li><a href="AddCereal.php">Cereals</a></li>
                    <li><a href="AddVegetable.php">Vegetables</a></li>
                    <li><a href="AddLegume.php">Legumes</a></li>
                    <li><a href="Livestock.php">Livestock</a></li>
                    <li><a href="Aquaculture.php">Aquaculture</a></li>
-->
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="logout.php">Logout</a></li>
                    <li><a href="index.php">Visit Site</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
